<?php if(session("mensaje")): ?>
<div class="alert alert-warning alert-dismissible" data-auto-dismiss="3000">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <h5><i class="icon fas fa-check"></i> Mensaje Control turnos</h5>
       <li><?php echo e(session("mensaje")); ?></li>
</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/includes/form-mensaje.blade.php ENDPATH**/ ?>