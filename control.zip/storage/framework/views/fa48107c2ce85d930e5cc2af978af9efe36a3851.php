<div class="form-group row">
    <div class="col-lg-3">
        <label for="cargo_id" class="col-xs-4 control-label requerido">Cargo</label>
        <select name="position" id="cargo_id" class="form-control select2bs4"
            style="width: 100%;" required>
        </select>
    </div>

    <div class="col-lg-3">
        <label for="eps" class="col-xs-4 control-label ">Eps</label>
        <select name="eps" id="eps" class="form-control select2bs4"
            style="width: 100%;" >
        </select>
    </div>
    <div class="col-lg-2">
        <label for="arl" class="col-xs-4 control-label ">Arl</label>
        <select name="arl" id="arl" class="form-control select2bs4"
            style="width: 100%;" >
        </select>
    </div>
    <div class="col-lg-2">
        <label for="afp" class="col-xs-4 control-label ">Afp</label>
        <select name="afp" id="afp" class="form-control select2bs4"
            style="width: 100%;" >
        </select>
    </div>
    <div class="col-lg-2">
        <label for="fc" class="col-xs-4 control-label ">F.
            Cesantias</label>
        <select name="fc" id="fc" class="form-control select2bs4"
            style="width: 100%;" >
        </select>
    </div>


</div>
<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/nomina/empleados/form/formdatosafiliaciones.blade.php ENDPATH**/ ?>