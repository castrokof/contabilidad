 <!-- Main Sidebar Container -->
  <aside class="main-sidebar  sidebar-light-info elevation-4 ">
    <!-- Brand Logo -->
    <a href="#" class="brand-link logo-switch">
    <img src="<?php echo e(asset("assets/img/icon_aside.jpeg")); ?>" alt="contabilidad_icon _aside" class="brand-image-xl logo-l" style="left: 2px">
    <img src="<?php echo e(asset("assets/img/icon_aside1.jpeg")); ?>" alt="contabilidad_icon_logo_aside" class="brand-image-l logo-l" style="left: 12px">
    </a>

    <!-- Sidebar -->
    <div class="sidebar sidebar-light-info sidebar-collapse">
      

      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul id="sidebar-menu" class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <div class="user-panel mt-1 pb-1 mb-1 d-flex">
           <div class="info">
            <i class="fa fa-bars" aria-hidden="false"></i>
           </div>
          <div class="info">
            <i class="nav-item has-treeview">
            <H5 alignt="center">Control Financiero</H5>
            </i>
         </div>
          </div>

           <?php $__currentLoopData = $menusComposer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <?php if($item["menu_id"] != 0): ?>
                 <?php break; ?>
               <?php endif; ?>
               <?php echo $__env->make("theme.$theme.menu-item", ["item" => $item], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>
<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/theme/lte/aside.blade.php ENDPATH**/ ?>