<div class="row">
    <div class="col-12">
        <div id="cardtabspro" class="card card-info card-tabs">
            <div class="card-header p-0 pt-1">
                <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="custom-tabs-one-datos-del-empleado-tab" data-toggle="pill"
                            href="#custom-tabs-one-datos-del-empleado" role="tab"
                            aria-controls="custom-tabs-one-datos-del-empleado" aria-selected="false">Información
                            Proveedor</a>
                    </li>
                    
                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content" id="custom-tabs-one-tabContent">
                    <form id="form-general" class="form-horizontal" method="POST">
                        <div class="tab-pane fade active show" id="custom-tabs-one-datos-del-empleado" role="tabpanel"
                            aria-labelledby="custom-tabs-one-datos-del-empleado-tab">
                            <div class="card-body">


                                <?php echo $__env->make('facturacion.proveedores.form.formdatosbasicos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            </div>
                        </div>

                        

                    </form>
                </div>
            </div>
            <!-- /.card -->
        </div>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/facturacion/proveedores/tabs/tabsproveedores.blade.php ENDPATH**/ ?>