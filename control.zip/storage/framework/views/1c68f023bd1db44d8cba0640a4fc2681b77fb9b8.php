    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">

                <div class="card card-success card-outline">
                    <div class="card-body box-profile">

                        <div class="direct-chat-messages" id="btnalert">
                         <?php echo csrf_field(); ?>
                         <?php echo $__env->make('paliativos.tablas.tablaAlertas', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>

                    </div>
                </div>
            </div>


        </div>
    </div>
<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/paliativos/form/formAnalistaAlertasResumen.blade.php ENDPATH**/ ?>