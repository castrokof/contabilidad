<div class="form-group row">
    <div class="col-md-10">
        <label for="file3" class="col-xs-4 control-label requerido">Busca el archivo de Auxiliares</label>
        <input type="file" name="file3" id="file3">
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/admin/import/form3.blade.php ENDPATH**/ ?>