<div class="card-body with-border">

    <div class="card-body  table-responsive col-lg-12 card-border mt-0 mb-0 pb-0 pt-1 pl-2 pr-2">

        <table id="baseAlertas" class="table table-sm table-hover  text-nowrap table-striped">
            <thead>
                <tr>
                    <th>Acciones</th>
                    <th>1Nombre</th>
                    <th>2Nombre</th>
                    <th>1Apellido</th>
                    <th>2Apellido</th>
                    <th>documento</th>
                    <th>Observación</th>
                    <th>Tipo</th>
                    <th>Sub tipo</th>
                    <th>Fecha alerta</th>

                </tr>
            </thead>
            <tbody>
            </tbody>

        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\coll_nomina\resources\views/paliativos/tablas/tablaAlertas.blade.php ENDPATH**/ ?>