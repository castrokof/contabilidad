<div class="form-group row">
    <div class="col-md-10">
        <label for="file2" class="col-xs-4 control-label requerido">Busca el archivo de Pacientes</label>
        <input type="file" name="file2" id="file2">
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/admin/import/form2.blade.php ENDPATH**/ ?>