 <!-- Modal del resumen -->

 <div class="modal fade" tabindex="-1" id ="modal-resumen"  role="dialog" aria-labelledby="myLargeModalLabel">
    <div class="modal-dialog modal-xl" role="document">

          <div class="modal-content bg-lite">
             <div class="modal-header">
                <h5 class="modal-title-resumen" id="myLargeModalLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                  </button>

            </div>
        <div class="modal-body">

        <form id="form-general" name="form-general" class="form-horizontal" method="post">
                <?php echo csrf_field(); ?>


                <?php echo $__env->make('lineaPsicologica.form.formAnalista', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        </form>
        </div>


        <div class="modal-footer">
            <button type="button" id="reportare" class="btn btn-success">Reportar</button>

        </div>

        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/lineaPsicologica/modal/modalindexresumen.blade.php ENDPATH**/ ?>