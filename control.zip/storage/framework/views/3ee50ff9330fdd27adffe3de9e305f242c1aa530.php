<div class="card-body with-border">

    <div class="card-body table-responsive p-2">

        <table id="basePaliativosUa" class="table table-hover  text-nowrap table-striped">
            <thead>
                <tr>
                    <th>Acciones</th>
                    <th>1Nombre</th>
                    <th>2Nombre</th>
                    <th>1Apellido</th>
                    <th>2Apellido</th>
                    <th>Tipo de documento</th>
                    <th>documento</th>
                    <th>Aux Alex</th>
                    <th>Aux Beimar</th>
                    <th>Aux Linda</th>
                    <th>Aux Eduar</th>
                    <th>Aux Deiby</th>
                    <th>Aux Aleja</th>
                    <th>Estado</th>
                    <th>tipo</th>
                    <th>Dias Alex</th>
                    <th>Dias Beimar</th>
                    <th>Dias Linda</th>
                    <th>Dias Eduar</th>
                    <th>Dias Deiby</th>
                    <th>Dias Aleja</th>


                </tr>
            </thead>
            <tbody>
            </tbody>

        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/paliativos/tablas/tablaPaliativosUltimaAux.blade.php ENDPATH**/ ?>