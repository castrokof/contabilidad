<div class="row">
    <div class="col-12">
        <div class="card shadow-lg p-3 mb-5 card-info card-tabs">
            <div class="card-header p-0 pt-1">
                <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="custom-tabs-one-datos-de-bdpaliativos-tab" data-toggle="pill"
                            href="#custom-tabs-one-datos-de-bdpaliativos" role="tab"
                            aria-controls="custom-tabs-one-datos-de-bdpaliativos" aria-selected="false">Pacientes
                            Totales Paliativos</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " id="custom-tabs-one-datos-de-bdpaliativos-sincontac-tab" data-toggle="pill"
                            href="#custom-tabs-one-datos-de-bdpaliativos-sincontac" role="tab"
                            aria-controls="custom-tabs-one-datos-de-bdpaliativos-sincontac"
                            aria-selected="false">Pacientes
                            Sin contacto => seguimiento</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " id="custom-tabs-one-datos-de-bdpaliativos-domi-tab" data-toggle="pill"
                            href="#custom-tabs-one-datos-de-bdpaliativos-domi" role="tab"
                            aria-controls="custom-tabs-one-datos-de-bdpaliativos-domi" aria-selected="false">Pacientes
                            Domiciliarios</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " id="custom-tabs-one-datos-de-bdpaliativos-upe-tab" data-toggle="pill"
                            href="#custom-tabs-one-datos-de-bdpaliativos-upe" role="tab"
                            aria-controls="custom-tabs-one-datos-de-bdpaliativos-upe" aria-selected="false">Ultima
                            Cita Paliativos - Experto</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " id="custom-tabs-one-datos-de-bdpaliativos-upef-tab" data-toggle="pill"
                            href="#custom-tabs-one-datos-de-bdpaliativos-upef" role="tab"
                            aria-controls="custom-tabs-one-datos-de-bdpaliativos-upef" aria-selected="false">filtro
                            Cita Paliativos - Experto</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link " id="custom-tabs-one-datos-de-bdpaliativos-ua-tab" data-toggle="pill"
                            href="#custom-tabs-one-datos-de-bdpaliativos-ua" role="tab"
                            aria-controls="custom-tabs-one-datos-de-bdpaliativos-ua" aria-selected="false">filtro
                            Cita Aux</a>
                    </li>
                </ul>
                </ul>
            </div>


            <div class="tab-content" id="custom-tabs-one-tabContent">
                <div class="tab-pane fade active show" id="custom-tabs-one-datos-de-bdpaliativos" role="tabpanel"
                    aria-labelledby="custom-tabs-one-datos-de-bdpaliativos-tab">

                    <?php echo $__env->make('paliativos.form.formConsultaAdd', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('paliativos.tablas.tablaPaliativos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>


                <div class="tab-pane fade " id="custom-tabs-one-datos-de-bdpaliativos-sincontac" role="tabpanel"
                    aria-labelledby="custom-tabs-one-datos-de-bdpaliativos-sincontac-tab">


                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('paliativos.tablas.tablaPaliativosSinC', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <div class="tab-pane fade " id="custom-tabs-one-datos-de-bdpaliativos-domi" role="tabpanel"
                    aria-labelledby="custom-tabs-one-datos-de-bdpaliativos-domi-tab">


                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('paliativos.tablas.tablaPaliativosDomi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <div class="tab-pane fade " id="custom-tabs-one-datos-de-bdpaliativos-upe" role="tabpanel"
                    aria-labelledby="custom-tabs-one-datos-de-bdpaliativos-upe-tab">


                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('paliativos.tablas.tablaPaliativosUltimaPaliExpe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <div class="tab-pane fade " id="custom-tabs-one-datos-de-bdpaliativos-upef" role="tabpanel"
                    aria-labelledby="custom-tabs-one-datos-de-bdpaliativos-upef-tab">


                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('paliativos.tablas.tablaPaliativosUltimaPaliExpef', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
                <div class="tab-pane fade " id="custom-tabs-one-datos-de-bdpaliativos-ua" role="tabpanel"
                    aria-labelledby="custom-tabs-one-datos-de-bdpaliativos-ua-tab">


                    <?php echo csrf_field(); ?>
                    <?php echo $__env->make('paliativos.tablas.tablaPaliativosUltimaAux', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>
            </div>

            <!-- /.card -->
        </div>
    </div>
    <button type="button" class="btn-flotante tooltipsC" id="agregar_paciente" title="Agregar paciente"><i
            class="fa fa-fw fa-plus-circle fa-2x"></i><i class="fa fa-user fa-2x"></i></button>

</div>
<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/paliativos/tabs/IndexTabls.blade.php ENDPATH**/ ?>