<div class="form-group row">
    <div class="col-md-10">
        <label for="file1" class="col-xs-4 control-label requerido">Busca el archivo ultima consulta Paliativos-Experto</label>
        <input type="file" name="file1" id="file1">
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/admin/import/form1.blade.php ENDPATH**/ ?>