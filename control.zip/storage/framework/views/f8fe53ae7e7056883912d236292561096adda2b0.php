<div class="row">
    <div class="col-12">
        <div id="cardtabspro" class="card card-bg-dark card-tabs">
            <div class="card-header p-0 pt-1">
                <ul class="nav nav-tabs" id="custom-tabs-one-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="custom-tabs-one-datos-del-ingreso-tab" data-toggle="pill"
                            href="#custom-tabs-one-datos-del-ingreso" role="tab"
                            aria-controls="custom-tabs-one-datos-del-ingreso" aria-selected="false">Información
                            Ingreso</a>
                    </li>
                     <li class="nav-item">
                        <button type="button" class="btn create_cuenta btn-default" name="create_cuenta" id="create_cuenta"><i class="fa fa-fw fa-plus-circle"></i> Nueva cuenta</button>

                    </li>

                </ul>
            </div>
            <div class="card-body">
                <div class="tab-content" id="custom-tabs-one-tabContent">
                    <form id="form-general" class="form-horizontal" method="POST">
                        <div class="tab-pane fade active show" id="custom-tabs-one-datos-del-ingreso" role="tabpanel"
                            aria-labelledby="custom-tabs-one-datos-del-ingreso-tab">
                            <div class="card-body">


                                <?php echo $__env->make('facturacion.ingresos.form.formdatosbasicos', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            </div>
                        </div>

                        

                    </form>
                </div>
            </div>
            <!-- /.card -->
        </div>

    </div>

</div>
<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/facturacion/ingresos/tabs/tabsingresos.blade.php ENDPATH**/ ?>