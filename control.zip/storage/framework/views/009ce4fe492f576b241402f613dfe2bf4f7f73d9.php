<div class="row">
<input type="hidden" name="action" id="action" value="Add"/>
<input type="hidden" name="hidden_id" id="hidden_id" value="Add"/>
<div class="col-xs-3">
<button value ="clean" id="clean" type="reset" class="btn btn-default">Limpiar</button>
<input type ="submit" name="action_button" id="action_button" class="addempleado btn btn-success" value="Add"/>
</div>
</div>
<?php /**PATH C:\xampp\htdocs\coll_nomina\resources\views/includes/boton-form-crear-empresa-empleado-usuario.blade.php ENDPATH**/ ?>