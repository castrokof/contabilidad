<div class="container-fluid">
        <div class="row">
          <div class="col-lg-3 col-6" id="detalle">
          </div>
          <div class="col-lg-3 col-6" id="detalle1">
          </div>
          <div class="col-lg-3 col-6" id="detalle2">
          </div>
          <div class="col-lg-3 col-6" id="detalle3">
          </div>
        </div>
        <div class="row">
            <div class="col-lg-3 col-6" id="detalle4">
            </div>
            <div class="col-lg-3 col-6" id="detalle5">
            </div>
            <div class="col-lg-3 col-6" id="detalle6">
            </div>
            <div class="col-lg-3 col-6" id="detalle7">
            </div>
        </div>
</div>
<?php /**PATH C:\xampp\htdocs\coll_nomina\resources\views/paliativos/cards/cards.blade.php ENDPATH**/ ?>