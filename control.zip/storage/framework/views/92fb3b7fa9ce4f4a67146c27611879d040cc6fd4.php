<div class="form-group row">
    <div class="col-md-10">
        <label for="file" class="col-xs-4 control-label requerido">Busca el archivo estado</label>
        <input type="file" name="file" id="file">
    </div>
</div>


<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/admin/import/form.blade.php ENDPATH**/ ?>