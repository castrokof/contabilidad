<div class="form-group row">
    <div class="col-lg-3">
        <label for="surnamee" class="col-xs-4 control-label requerido">Primer nombre</label>
        <input type="text" name="surname" id="surnamee" class="form-control UpperCase" value="<?php echo e(old('surname')); ?>" required >
    </div>
    <div class="col-lg-3">
        <label for="ssurnamee" class="col-xs-4 control-label ">Segundo nombre</label>
        <input type="text" name="ssurname" id="ssurnamee" class="form-control UpperCase" value="<?php echo e(old('ssurname')); ?>"  >
    </div>
    <div class="col-lg-3">
        <label for="fnamee" class="col-xs-4 control-label requerido">Primer apellido</label>
        <input type="text" name="fname" id="fnamee" class="form-control UpperCase" value="<?php echo e(old('fname')); ?>" required >
    </div>
    <div class="col-lg-3">
        <label for="snamee" class="col-xs-4 control-label ">Segundo apellido</label>
        <input type="text" name="sname" id="snamee" class="form-control UpperCase" value="<?php echo e(old('sname')); ?>"  >
    </div>
    </div>
    <div class="form-group row">
  
    <div class="col-lg-3">
        <label for="date_birthe" class="col-xs-4 control-label requerido">Fecha nac</label>
        <input type="date" name="date_birth" id="date_birthe" class="form-control" value="<?php echo e(old('date_birth')); ?>" required >
        </div>
   

    <div class="col-lg-3">
        <label for="municipalitye" class="col-xs-4 control-label requerido">Municipio</label>
        <select name="municipality" id="municipalitye" class="form-control select2bs4" style="width: 100%;" required>
        <option value="">---seleccione---</option>
        <option value="Cali">Cali</option>
        <option value="Palmira">Palmira</option>
        <option value="Buenaventura">Buenaventura</option>
        <option value="Jamundi">Jamundi</option>
        <option value="Yumbo">Yumbo</option>
        <option value="Otro">Otro</option>
    </select>
    </div>

    <div class="col-lg-2" id="municipio_otrase" style="display: none;">
        <label for="other" class="col-xs-4 control-label requerido">Otro</label>
        <input type="text" name="other" id="othere" class="form-control UpperCase" value="<?php echo e(old('other')); ?>" >
    </div>
    
    <div class="col-lg-3">
        <label for="zona" class="col-xs-4 control-label requerido">Zona</label>
        <select name="future1" id="zona" class="form-control select2bs4" style="width: 100%;" required>
       
        </select>
    </div>

</div>
    <div class="form-group row">
    <div class="col-lg-3">
    <label for="addresse" class="col-xs-4 control-label requerido">Direccion</label>
    <input type="text" name="address" id="addresse" class="form-control UpperCase" value="<?php echo e(old('address')); ?>" minlength="6" required >
    </div>
    <div class="col-lg-3">
        <label for="celulare" class="col-xs-4 control-label requerido">Celular</label>
        <input type="number" name="celular" id="celulare" class="form-control" value="<?php echo e(old('celular')); ?>" required>
    </div>
    <div class="col-lg-3">
        <label for="phonee" class="col-xs-4 control-label requerido">Telefono</label>
        <input type="number" name="phone" id="phonee" class="form-control" value="<?php echo e(old('phone')); ?>" required>
    </div>

    <div class="col-lg-3">
        <label for="emaile" class="col-xs-4 control-label ">E-mail</label>
        <input type="email" name="email" id="emaile" class="form-control" value="<?php echo e(old('email')); ?>">
    </div>

    </div>
    <div class="form-group row">
        <div class="col-lg-3">
            <label for="sexoe" class="col-xs-4 control-label requerido">Sexo</label>
            <select name="sex" id="sexe" class="form-control select2bs4" style="width: 100%;" required>
                <option value="">---seleccione---</option>
                <option value="M">MASCULINO</option>
                <option value="F">FEMENINO</option>
            </select>
        </div>
 
            <div class="col-lg-3">
                <label for="date_ine" class="col-xs-4 control-label requerido">Fecha In </label>
                <input type="date" name="date_in" id="date_ine" class="form-control" value="<?php echo e(old('date_in')); ?>" required >
            </div>


    </div>
 

    <input type="hidden" name="user_id" id="user_ide" class="form-control" value="<?php echo e(Session()->get('usuario_id')); ?>" >





<?php /**PATH C:\xampp\htdocs\coll_nomina\resources\views/paliativos/form/formPacienteEdit.blade.php ENDPATH**/ ?>