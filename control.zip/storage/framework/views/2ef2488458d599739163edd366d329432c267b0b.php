<div class="content-header">
        <div class="container-fluid">
                  <div class="card-body m-0 p-1">
                    <div class="form-group row col-9">

                           <div class="col-lg-2 col-mb-2">
                                <label for="stateb" class="col-mb-2 control-label ">Estado</label>
                                <select name="state" id="stateb" class="form-control select2bs4"
                                    style="width: 100%;">
                                </select>
                            </div>
                             <?php if(session()->get('rol_id') == 1 || session()->get('rol_id') == 2): ?>
                             <div class="col-lg-2 col-mb-2">
                                <label for="zonab" class="col-mb-2 control-label ">Zona</label>
                                <select name="zonab" id="zonab" class="form-control select2bs4"
                                    style="width: 100%;">
                                </select>
                            </div>
                            
                             <div class="col-lg-2 col-mb-2">
                                <label for="profesionalb" class="col-mb-2 control-label ">Profesional</label>
                                <select name="profesionalb" id="profesionalb" class="form-control select2bs4"
                                    style="width: 100%;">
                                </select>
                            </div>
                           
                             <div class="col-lg-2 col-mb-2">
                                <label for="statepacb" class="col-mb-2 control-label ">Estado Pac</label>
                                <select name="statepacb" id="statepacb" class="form-control select2bs4"
                                    style="width: 100%;">
                                    
                                </select>
                            </div>
                             <?php endif; ?>
                            <div class="col-lg-2 col-mb-2">
                              <label class="col-mb-2 control-label">&nbsp;</label><br>
                              <button type="button" id="buscarstate" class="btn btn-success btn-xl col-mb-2">Buscar</button>
                               <?php if(session()->get('rol_id') == 1 || session()->get('rol_id') == 2): ?>
                              <button type="reset" id="reset_fill" class="btn btn-warning btn-xl col-mb-2">Reset</button>
                               <?php endif; ?>

                            </div>

                   


                    </div>
                </div><!-- /.row -->
           
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\medcol_contabilidad\resources\views/paliativos/form/formConsultaAdd.blade.php ENDPATH**/ ?>