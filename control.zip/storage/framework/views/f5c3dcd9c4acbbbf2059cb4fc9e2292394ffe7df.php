<div class="card-body with-border">

    <div class="card-body table-responsive  mt-0 mb-0 pb-0 pt-1 pl-2 pr-2">

        <table id="basePaliativos" class="table table-sm table-hover  text-nowrap table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>Det</th>
                    <th>Acciones</th>
                    <th>Estado</th>
                    <th>EstadoPac</th>
                    <th>Profesional</th>
                    <th>1Nombre</th>
                    <th>2Nombre</th>
                    <th>1Apellido</th>
                    <th>2Apellido</th>
                    <th>Tipo de documento</th>
                    <th>documento</th>
                    <th>F nacimiento</th>
                    <th>Diagnostico</th>
                    <th>Ciudad</th>
                    <th>Dirección</th>
                    <th>Celular</th>
                    <th>Telefono</th>
                    <th>Email</th>
                    <th>Observación</th>
                    <th>Fecha Ingreso</th>
                    <th>Falleció</th>
                    <th>Fecha de fallecimiento</th>
                    <th>Tipo atención</th>

                </tr>
            </thead>
            <tbody>
            </tbody>

        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\coll_nomina\resources\views/paliativos/tablas/tablaPaliativos.blade.php ENDPATH**/ ?>