<div class="card-body with-border">

    <div class="card-body table-responsive p-2">

        <table id="basePaliativosUpe" class="table table-hover  text-nowrap table-striped">
            <thead>
                <tr>
                    <th>Acciones</th>
                    <th>1Nombre</th>
                    <th>2Nombre</th>
                    <th>1Apellido</th>
                    <th>2Apellido</th>
                    <th>Tipo de documento</th>
                    <th>documento</th>
                    <th>Pali Alejandra</th>
                    <th>Pali Sara</th>
                    <th>Expe Ana</th>
                    <th>Expe Catalina</th>
                    <th>Expe Sebastian</th>
                    <th>Estado</th>
                    <th>tipo</th>
                    <th>dias ale</th>
                    <th>dias Sara</th>
                    <th>dias Ana</th>
                    <th>dias Cata</th>
                    <th>dias Seba</th>


                </tr>
            </thead>
            <tbody>
            </tbody>

        </table>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\coll_nomina\resources\views/paliativos/tablas/tablaPaliativosUltimaPaliExpe.blade.php ENDPATH**/ ?>