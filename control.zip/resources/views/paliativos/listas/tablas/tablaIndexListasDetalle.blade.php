<div class="row">
    <div class="col-lg-12">
        <div class="card card-info">
            <div class="card-body table-responsive p-2">

                <table id="listasGeneralDetalle" class="table table-hover  text-nowrap">

                    <thead>
                        <tr>
                            <th>accion</th>
                            <th>id</th>
                            <th>Slug</th>
                            <th>Nombre</th>
                            <th>Descripción</th>
                            <th>activo</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
