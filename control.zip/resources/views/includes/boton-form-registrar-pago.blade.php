<div class="form-group row">

<input type="hidden" name="action" id="action" value="Add"/>
<input type="hidden" name="usuario_id" id="hidden_id" value="Add"/>
<input type ="submit" name="action_button" id="action_button" class="btn btn-success" value="Guardar"/>

</div>
