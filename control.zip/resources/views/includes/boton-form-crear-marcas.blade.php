<button value ="reset" id="reset" type="reset" class="btn btn-default">Limpiar</button>
<button value ="subir" id="subir" type="submit" class="btn btn-success">Guardar</button>