<button type="submit" class="btn btn-success">Asignar</button>
<button type="submit" class="btn btn-danger">Desasignar</button>