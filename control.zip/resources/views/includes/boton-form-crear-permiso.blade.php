<button value ="reset" id="reset" type="reset" class="btn btn-default">Limpiar</button>
<button value ="guardar" id="guardar" type="submit" class="btn btn-success">Guardar</button>