<div class="form-group row col-lg-12">
    <div class="col-lg-6">
    <label for="password" class="col-xs-12 control-label requerido">Password</label>
    <input   type="password" name="password1" id="password1" class="form-control" value=""  minlength="6" required >
    </div>
    <div class="col-lg-6">
        <label for="remenber_token" class="col-xs-12 control-label requerido">repita el password</label>
        <input   type="password" name="remenber_token1" id="remenber_token1" class="form-control" value=""  minlength="6" required >
    </div>
    

</div>
