<button type="reset" class="btn btn-default">Limpiar</button>
<button type="submit" class="btn btn-success">Buscar</button>