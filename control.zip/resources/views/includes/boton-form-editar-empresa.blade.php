<button type="button" id="actualizar" name="actualizar" class="btn btn-success">Actualizar</button>
<input type="hidden" name="hidden_id" id="hidde_id" />