<div class="card-body with-border">
    <div class="card-body table-responsive p-2">

        <table id="tniveles" class="table table-hover  text-nowrap">

            <thead>
                <tr>
                    <th>Acciones</th>
                    <th>Fecha de Pago</th>
                    <th>Valor del Pago</th>
                    <th>Tipo de Pago</th>
                </tr>
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>
