<div class="card-body with-border">
      <div class="card-body table-responsive p-2">

      <table id="informepsicologica" class="table table-hover table-sm table-condensed text-nowrap table-striped">

        <thead>
        <tr>
              <th>Acciones</th>
              <th>Id</th>
              <th>Primer apellido</th>
              <th>Segundo apellido</th>
              <th>Primer nombre</th>
              <th>Segundo nombre</th>
              <th>Tipo Documento</th>
              <th>Documento</th>
              <th>Fecha de nacimiento</th>
              <th>Municipio</th>
              <th>Otro</th>
              <th>Direccion</th>
              <th>Celular</th>
              <th>Telefono</th>
              <th>Correo</th>
              <th>Sexo</th>
              <th>Eapb</th>
              <th>Motivo de consulta</th>
              <th>Consulta</th>
              <th>Diagnostico Psiqui</th>
              <th>Psicologa</th>
              <th>Fecha de creacion</th>


        </tr>
        </thead>
        <tbody>
        </tbody>
      </table>
    </div>

</div>

